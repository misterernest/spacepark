$(document).ready(function(){
  //constantes del programa
  const mts2 = 12;
  const width=2217;
  const height=1598;
  const zoom_proporcion = 0.3;
  const zoom_width = width * zoom_proporcion;
  const zoom_height = height*zoom_proporcion;
  let zoom = false;
  const areaDisponible1 = Array(
    [240, 360],
    [408, 360],
    [420, 96],
    [636, 120],
    [636, 156],
    [672, 156],
    [636, 468],
    [1548, 552],
    [1548, 1476],
    [1368, 1476],
    [1368, 973],
    [216, 961],
    [216, 720],
    [624, 720],
    [624, 576],
    [120, 576],
    [120, 383],
    [240, 360]
  );
  const areaDisponible2 = Array(
    [1596, 553],
    [1992, 600],
    [2028, 600],
    [2112, 756],
    [2076, 780],
    [2112, 888],
    [1596, 888],
    [1596, 553]
  );
/* Manejo del Canvas y su inicializacion */
  var canvas1 = $("#canvas1").get(0);
  const context1 = canvas1.getContext("2d");
  var canvas2 = $("#canvas2").get(0);
  const context2 = canvas2.getContext("2d");

/* Variables de fecha para hacer la consulta incial*/
  let hoy = new Date();
  let dd = hoy.getDate();
  let mm = hoy.getMonth()+1; //hoy es 0!
  let yyyy = hoy.getFullYear();



  /* Set en el tamaño para el manejo del zoom */
  $('#img-park').attr("width", zoom_width);
  $('#canvas1').attr("width", zoom_width);
  $('#canvas1').attr("height", zoom_height);
  $('#canvas2').attr("width", zoom_width);
  $('#canvas2').attr("height", zoom_height);
  $('#zoom').click(function(){
    zoomDo();
  });
  zonasMuertas(areaDisponible1);
  zonasMuertas(areaDisponible2);
/*  ****************************************************************************
FUNCIONES PRINCIPALES
********************************************************************************
 */
  /*
  Hace el zoom en el DOM
   */
  function zoomDo(){
    if (zoom) {
      zoom = false;
      $('#zoom-in').removeAttr("hidden");
      $('#zoom-out').attr("hidden", "hidden");
      $('#categorias').removeAttr("hidden", "hidden");
      $('#container-canvas').removeClass('width-100');
      $('#container-canvas').addClass('width-70');
      $('#img-park').attr("width", zoom_width);
      $('#canvas1').attr("width", zoom_width);
      $('#canvas1').attr("height", zoom_height);
      $('#canvas2').attr("width", zoom_width);
      $('#canvas2').attr("height", zoom_height);
      zonasMuertas(areaDisponible1);
      zonasMuertas(areaDisponible2);
    }else{
      zoom = true;
      $('#zoom-out').removeAttr("hidden");
      $('#zoom-in').attr("hidden", "hidden");
      $('#categorias').attr("hidden", "hidden");
      $('#container-canvas').removeClass('width-70');
      $('#container-canvas').addClass('width-100');
      $('#img-park').removeAttr("width");
      $('#canvas1').attr("width", width);
      $('#canvas1').attr("height", height);
      $('#canvas2').attr("width", width);
      $('#canvas2').attr("height", height);
      creaCuadricula(canvas1.width, canvas1.height);
      zonasMuertas(areaDisponible1);
      zonasMuertas(areaDisponible2);
    }
  }

  /*
  Pinta la cuadricula en el mapa con zoom
   */
  function creaCuadricula(widthReg, heightReg){
    if (context1) {
      context1.lineWidth = 0.1;
      context1.strokeStyle = "#000";
      for (let i = 0; i <= widthReg; i= i + mts2) {
        context1.beginPath();
        context1.moveTo(i, 0);
        context1.lineTo(i, heightReg);
        context1.stroke();
      }
      for (let i = 0; i <= heightReg; i= i + mts2) {
        context1.strokeStyle = "#000";
        context1.beginPath();
        context1.moveTo(0, i);
        context1.lineTo(widthReg, i);
        context1.stroke();
      }
    }
  }

  /*
  DIBUJA LA LINEA DEL PERIMETRO PERMITIDO
   */

   function zonasMuertas(arrayCoordenadas){
     if (context1) {
       let proporcion = (zoom)?1:zoom_proporcion;
       context1.lineWidth = 1;
   		context1.strokeStyle = "rgb(0,0,0)";
       for (var i = 0; i < arrayCoordenadas.length-1; i++) {

         context1.beginPath();
   			context1.lineJoin = "round";
   			context1.moveTo(arrayCoordenadas[i][0]*proporcion, arrayCoordenadas[i][1]*proporcion);
   			context1.lineTo(arrayCoordenadas[i][0]*proporcion, arrayCoordenadas[i][1]*proporcion);
   			context1.lineTo(arrayCoordenadas[i+1][0]*proporcion, arrayCoordenadas[i+1][1]*proporcion);
   			context1.stroke();
       }
     }
   }
/* **************************************************************************** */
/*
  FUNCIONES CON BASE DE DATOS
 */
/* Consulta la base de datos por meses */
consultarBaseDatos ('2018-01-17', 30);
 function consultarBaseDatos (date,dias){

 // Convertir a objeto
 var data = {};

 data.date = date;
 data.dias = dias;
 data.categoria = '';

 var url = 'consultar.php';   //este es el PHP al que se llama por AJAX

 	resultado = new Array();
     $.ajax({
         method: 'POST',
         url: url,
         data: data,   //acá están todos los parámetros (valores a enviar) del POST
         success: function(response){
             // resultado es un array con el resultado del query
             resultado = response;
 			console.log(resultado);
         },
 		dataType:"json"
     });
 }

});
