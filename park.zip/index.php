<!DOCTYPE html>
<!-- saved from url=(0058)http://www.themehelite.com/themeforest/future/index-2.html -->
<html lang="en-us">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<style type="text/css">.gm-style .gm-style-mtc label,.gm-style .gm-style-mtc div{font-weight:400}</style>
	<link type="text/css" rel="stylesheet" href="files/css">
	<style type="text/css">.gm-style .gm-style-cc span,.gm-style .gm-style-cc a,.gm-style .gm-style-mtc div{font-size:10px}</style>
	<style type="text/css">@media print {  .gm-style .gmnoprint, .gmnoprint {    display:none  }}@media screen {  .gm-style .gmnoscreen, .gmnoscreen {    display:none  }}</style>
	<style type="text/css">.gm-style-pbc{transition:opacity ease-in-out;background-color:rgba(0,0,0,0.45);text-align:center}.gm-style-pbt{font-size:22px;color:white;font-family:Roboto,Arial,sans-serif;position:relative;margin:0;top:50%;-webkit-transform:translateY(-50%);-ms-transform:translateY(-50%);transform:translateY(-50%)}</style>
	<title>PTW park</title>
	<link rel="icon" type="image/png" href="img/logo-azul.png" />
	<meta name="description" content="Lorem ipsum dolor sit amet, consectetur adipiscing elit.">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="author" content="">
	<link href="files/css(1)" rel="stylesheet" type="text/css">
	<link href="files/bootstrap.min.css" rel="stylesheet">
	<link href="files/font-awesome.min.css" rel="stylesheet">
	<link href="files/animate.css" rel="stylesheet" type="text/css">
	<link href="files/style.css" rel="stylesheet" type="text/css"> <style media="screen">#pattern{z-index:1}#main-future{z-index:1001}#progress2{z-index:1}</style>
	<link rel="stylesheet" href="css/index.css">
	<script type="text/javascript" charset="UTF-8" src="files/common.js.descarga"></script>
	<script type="text/javascript" charset="UTF-8" src="files/map.js.descarga"></script>
	<script type="text/javascript" charset="UTF-8" src="files/util.js.descarga"></script>
	<script type="text/javascript" charset="UTF-8" src="files/marker.js.descarga"></script>
	<script type="text/javascript" charset="UTF-8" src="files/infowindow.js.descarga"></script>
	<style type="text/css">.gm-style {font: 400 11px Roboto, Arial, sans-serif;text-decoration: none;}.gm-style img { max-width: none; }</style>
	<script type="text/javascript" charset="UTF-8" src="files/onion.js.descarga"></script>
	<script type="text/javascript" charset="UTF-8" src="files/controls.js.descarga"></script>
	<script type="text/javascript" charset="UTF-8" src="files/stats.js.descarga"></script>
	<script type="text/javascript" charset="UTF-8" src="https://maps.googleapis.com/maps/api/js/ViewportInfoService.GetViewportInfo?1m6&amp;1m2&amp;1d48.97430612520873&amp;2d4.156642788778186&amp;2m2&amp;1d50.250107377209964&amp;2d8.107511182072358&amp;2u11&amp;4ses-ES&amp;5e0&amp;6sm%40407000000&amp;7b0&amp;8e0&amp;callback=_xdc_._r659ku&amp;token=85693"></script>
	<script type="text/javascript" charset="UTF-8" src="https://maps.googleapis.com/maps/vt?pb=!1m4!1m3!1i11!2i1055!3i696!1m4!1m3!1i11!2i1055!3i697!1m4!1m3!1i11!2i1055!3i698!1m4!1m3!1i11!2i1055!3i699!1m4!1m3!1i11!2i1056!3i696!1m4!1m3!1i11!2i1056!3i697!1m4!1m3!1i11!2i1057!3i696!1m4!1m3!1i11!2i1057!3i697!1m4!1m3!1i11!2i1056!3i698!1m4!1m3!1i11!2i1056!3i699!1m4!1m3!1i11!2i1057!3i698!1m4!1m3!1i11!2i1057!3i699!1m4!1m3!1i11!2i1058!3i696!1m4!1m3!1i11!2i1058!3i697!1m4!1m3!1i11!2i1059!3i696!1m4!1m3!1i11!2i1059!3i697!1m4!1m3!1i11!2i1058!3i698!1m4!1m3!1i11!2i1058!3i699!1m4!1m3!1i11!2i1059!3i698!1m4!1m3!1i11!2i1059!3i699!1m4!1m3!1i11!2i1060!3i696!1m4!1m3!1i11!2i1060!3i697!1m4!1m3!1i11!2i1061!3i696!1m4!1m3!1i11!2i1061!3i697!1m4!1m3!1i11!2i1060!3i698!2m3!1e0!2sm!3i407105410!3m14!2ses-ES!3sUS!5e18!12m1!1e68!12m3!1e37!2m1!1ssmartmaps!12m4!1e26!2m2!1sstyles!2zcC5oOiNmZjFhMDB8cC5pbDp0cnVlfHAuczotMTAwfHAubDozM3xwLmc6MC41LHMudDo2fHMuZTpnfHAuYzojZmYyRDMzM0M!4e3!12m1!5b1&amp;callback=_xdc_._8p44ax&amp;token=61357"></script>
	<script type="text/javascript" charset="UTF-8" src="https://maps.googleapis.com/maps/vt?pb=!1m4!1m3!1i11!2i1060!3i699!1m4!1m3!1i11!2i1061!3i698!1m4!1m3!1i11!2i1061!3i699!1m4!1m3!1i11!2i1062!3i696!1m4!1m3!1i11!2i1062!3i697!1m4!1m3!1i11!2i1062!3i698!1m4!1m3!1i11!2i1062!3i699!2m3!1e0!2sm!3i407105410!3m14!2ses-ES!3sUS!5e18!12m1!1e68!12m3!1e37!2m1!1ssmartmaps!12m4!1e26!2m2!1sstyles!2zcC5oOiNmZjFhMDB8cC5pbDp0cnVlfHAuczotMTAwfHAubDozM3xwLmc6MC41LHMudDo2fHMuZTpnfHAuYzojZmYyRDMzM0M!4e3!12m1!5b1&amp;callback=_xdc_._5qcnjq&amp;token=29982"></script>
</head>
<body onload="run();" style="">

	<div id="parent">
		<img id="background" alt="" src="img/1.png" crossorigin="anonymous">
	</div>
	<div id="pattern"></div>

	<section id="main-future" class="opacity-1 animated fadeIn">
		<div id="main-content">
			<div class="principal container">
				<div id="tit-main" class="animated fadeInDown">
					<img src="img/logo_ptw.png" alt="PTW - PARK">
				</div>
				<div class="container">
					<div class="row">
						<div class="col-sm-4 col-md-4 box-login">
							<h4>LOGIN:</h4>
							<form action="login.php" method="post">
								<div class="<?php echo ($_GET['error']== 1)?"alert alert-danger":"invisible"; ?>">
									<?php echo ($_GET['error']== 1)?"USUARIO O CLAVE INCORRECTO":""; ?>
								</div>
								<div>
									<input type="text" name="usuario" placeholder="USER">
								</div>
								<div>
									<input type="password" name="password" placeholder="PASSWORD">
								</div>
								<div>
									<input type="submit" value="SUBMIT" class="submit">
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>

	</section>



	<script type="text/javascript" src="files/rainyday.js.descarga"></script>

	<script>function run(){var image=document.getElementById('background');image.crossOrigin='anonymous';var engine=new RainyDay({element:'background',blur:0,opacity:1,fps:30});engine.trail=engine.TRAIL_SMUDGE;engine.rain([[1,0,100],[3,3,1]],100);} $(window).load(function(){run();});</script>
	<script>;(function($){$('.swipebox').swipebox();})(jQuery);</script>
	<!--script>(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)})(window,document,'script','//www.google-analytics.com/analytics.js','ga');ga('create','UA-60503361-1','auto');ga('send','pageview');</script-->
	<canvas width="1978" height="925" style="position: absolute; left: 0px; top: 0px; width: 1978px; height: 925px;"></canvas>
	<canvas width="1978" height="925" style="position: absolute; left: 0px; top: 0px; width: 1978px; height: 925px;"></canvas>
</body>
</html>
